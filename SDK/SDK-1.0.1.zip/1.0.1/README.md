# XNseries SDK v1.0.0

NOTE : SDK tools are only available on linux.

Public development SDK for XNseries userspace software.

See `docs/README.md` for the SDK overview and `docs/bcl-api.md` for the
BCL API mapping.
