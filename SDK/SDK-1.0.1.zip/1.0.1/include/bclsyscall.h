#ifndef SDK_BCLSYSCALL_H
#define SDK_BCLSYSCALL_H

#include <stdint.h>

uint64_t bclsyscall(
    uint64_t num,
    uint64_t arg1,
    uint64_t arg2,
    uint64_t arg3
);

#endif
