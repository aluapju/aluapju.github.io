#ifndef SDK_MATH_H
#define SDK_MATH_H

int abs(int value);

long labs(long value);

#endif
