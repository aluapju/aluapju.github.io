#ifndef SDK_ERRNO_H
#define SDK_ERRNO_H

int errno_get(void);

#endif
