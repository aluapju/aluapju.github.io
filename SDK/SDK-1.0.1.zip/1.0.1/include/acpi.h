#ifndef SDK_ACPI_H
#define SDK_ACPI_H

int shutdown(void);

int reboot(void);

#endif
