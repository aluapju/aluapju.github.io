#ifndef SDK_EXEC_H
#define SDK_EXEC_H

int exec(
    const char *path,
    char **argv,
    char **envp
);

#endif
