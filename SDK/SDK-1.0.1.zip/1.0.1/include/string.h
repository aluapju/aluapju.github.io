#ifndef SDK_STRING_H
#define SDK_STRING_H

#include <stddef.h>

size_t strlen(const char *str);

int strcmp(const char *lhs, const char *rhs);

int strncmp(
    const char *lhs,
    const char *rhs,
    size_t n
);

char *strcpy(
    char *dest,
    const char *src
);

char *strncpy(
    char *dest,
    const char *src,
    size_t n
);

void *memcpy(
    void *dest,
    const void *src,
    size_t n
);

int memcmp(
    const void *lhs,
    const void *rhs,
    size_t n
);

void *memset(
    void *dest,
    int value,
    size_t n
);

void *memmove(
    void *dest,
    const void *src,
    size_t n
);

#endif
