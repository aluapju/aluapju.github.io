#ifndef SDK_SLEEP_H
#define SDK_SLEEP_H

#include <stdint.h>

int sleep(uint64_t milliseconds);

#endif
