#ifndef SDK_KEYBOARD_H
#define SDK_KEYBOARD_H

#include <stdint.h>

int keyboard_register(uint64_t callback);

int keyboard_unregister(uint64_t callback);

#endif
