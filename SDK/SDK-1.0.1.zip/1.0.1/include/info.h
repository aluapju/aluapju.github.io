#ifndef SDK_INFO_H
#define SDK_INFO_H

#include <stdint.h>

int get_info(
    uint64_t info_type,
    void *info
);

#endif
