#ifndef SDK_RUNTIME_H
#define SDK_RUNTIME_H

void runtime_init(void);

_Noreturn void runtime_abort(
    const char *reason
);

#endif
