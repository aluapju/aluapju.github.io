#ifndef SDK_MM_H
#define SDK_MM_H

#include <stddef.h>

void *heap_alloc(size_t size);

#endif
