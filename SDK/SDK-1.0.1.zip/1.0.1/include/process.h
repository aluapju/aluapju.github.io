#ifndef SDK_PROCESS_H
#define SDK_PROCESS_H

#include <stdint.h>

_Noreturn void process_exit(int status);

int process_exec(const char *path);

uint64_t proc(
    const char *command,
    void *arg
);

#endif
