#ifndef SDK_VGA_H
#define SDK_VGA_H

int vga_write(const char *str);

#endif
