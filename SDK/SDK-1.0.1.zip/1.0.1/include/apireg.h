#ifndef SDK_APIREG_H
#define SDK_APIREG_H

#include <stdint.h>

uint64_t api_register(
    const char *name,
    uint64_t *address,
    const char *type
);

#endif
