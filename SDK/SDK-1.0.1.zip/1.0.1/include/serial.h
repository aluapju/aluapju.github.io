#ifndef SDK_SERIAL_H
#define SDK_SERIAL_H

int serial_printf(
    const char *fmt,
    ...
);

#endif
