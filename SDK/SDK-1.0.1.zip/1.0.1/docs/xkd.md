# XKD Toolchain

XKD is the driver/package format used by XNseries.

The XKD build process is:

```text
.c
 │
 │ gcc (GNU)
 ▼
.o
 │
 │ ld (GNU)
 ▼
.elf
 │
 │ xkd-pack
 ▼
.xkd
```

## Build Process

### 1. Compile C source

Compile the C source into an object file using GNU GCC:

```bash
gcc -c driver.c -o driver.o
```

Additional source files can be compiled in the same way:

```bash
gcc -c device.c -o device.o
gcc -c helper.c -o helper.o
```

### 2. Link object files into ELF

Use the GNU linker (`ld`) to produce an ELF file:

```bash
ld -o driver.elf driver.o device.o helper.o
```

The result is:

```text
driver.elf
```

### 3. Pack ELF into XKD

Use `xkd-pack` to convert the ELF file into an XKD package:

```bash
xkd-pack driver.elf driver.xkd
```

The result is:

```text
driver.xkd
```

---

# Complete Example

```bash
gcc -c driver.c -o driver.o
gcc -c device.c -o device.o

ld -o driver.elf \
    driver.o \
    device.o

xkd-pack driver.elf driver.xkd
```

The complete build flow is:

```text
driver.c
    │
    │ gcc
    ▼
driver.o
    │
    │ ld
    ▼
driver.elf
    │
    │ xkd-pack
    ▼
driver.xkd
```

---

# Tool Summary

| Tool        | Purpose                    |
| ----------- | -------------------------- |
| `gcc` (GNU) | Compile `.c` into `.o`     |
| `ld` (GNU)  | Link `.o` into `.elf`      |
| `xkd-pack`  | Convert `.elf` into `.xkd` |

## Important

The XKD toolchain uses standard GNU compilation and linking for the intermediate ELF image.

`xkd-pack` is then used to package the resulting ELF into the XKD format.

