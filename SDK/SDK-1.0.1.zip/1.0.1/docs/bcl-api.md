# BCL API Reference

The following declarations are derived from BCL-1.0.0.

## string.h

- `strlen`
- `strcmp`
- `strncmp`
- `strcpy`
- `strncpy`
- `memcpy`
- `memcmp`
- `memset`
- `memmove`

## bclsyscall.h

- `bclsyscall`

## acpi.h

- `shutdown`
- `reboot`

## apireg.h

- `api_register`

## errno.h

- `errno_get`

## math.h

- `abs`
- `labs`

## process.h

- `process_exit`
- `process_exec`
- `proc`

## exec.h

- `exec`

## mm.h

- `heap_alloc`

## sleep.h

- `sleep`

## info.h

- `get_info`

## vga.h

- `vga_write`

## keyboard.h

- `keyboard_register`
- `keyboard_unregister`

## runtime.h

- `runtime_init`
- `runtime_abort`

## serial.h

- `serial_printf`
