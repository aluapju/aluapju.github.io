# XDL Toolchain

XDL is the dynamic library format used by XNCOS userspace software.

An XDL file is a **library**, not an executable program.

The XNseries SDK provides the following XDL development tools:

```text
SDK/tools/xdl/
├── xdl_ld
└── readxdl
```

## Tools

### xdl_ld

`xdl_ld` links object files and produces an XDL library.

### readxdl

`readxdl` reads and displays information from an XDL library.

---

# XDL Build Process

XDL compilation is intentionally simple.

The basic build flow is:

```text
.c / .asm
    │
    ├── gcc
    │
    └── nasm
         │
         ▼
        .o
         │
         │ xdl_ld
         ▼
        .xdl
```

## 1. Compile source files

C source files can be compiled into object files using GCC:

```bash
gcc -c one.c -o one.o
gcc -c two.c -o two.o
```

Assembly source files can be assembled into ELF64 object files using NASM:

```bash
nasm -f elf64 one.asm -o one.o
```

The resulting object files can then be passed to `xdl_ld`.

## 2. Link the XDL library

Use `xdl_ld` to produce the XDL library:

```bash
xdl_ld -o world.xdl one.o two.o
```

This produces:

```text
world.xdl
```

---

# XDL Is a Library

**XDL is a dynamic library and must not be built as an executable program.**

An XDL library should **not** contain:

```text
main
start
executable entry point
```

In particular, developers must not add a `main()` function or executable startup code to an XDL library.

The library should instead provide functions and data that can be used by programs or other runtime components.

For example:

```text
library.c
    │
    ▼
library.o
    │
    ▼
xdl_ld
    │
    ▼
library.xdl
```

The resulting XDL provides library functionality rather than a program entry point.

---

# Example

Compile the source files:

```bash
gcc -c string.c -o string.o
gcc -c memory.c -o memory.o
```

Then create the XDL library:

```bash
xdl_ld -o libexample.xdl \
    string.o \
    memory.o
```

Result:

```text
libexample.xdl
```

No `main()` or `start.asm` is required.

---

# Important Warning

> **XDL is a library. Do not put `main`, `start`, or any executable entry point into an XDL library.**

The executable startup sequence belongs to the XNC executable that uses the library.

XDL should contain the reusable functionality provided by the library.

---

# Inspecting an XDL Library

After building an XDL library, use `readxdl` to inspect it:

```bash
readxdl world.xdl
```

This can be used to inspect the XDL header, segments, symbols, relocations, exports, and other library metadata.

---

# Tool Summary

| Tool      | Purpose                               |
| --------- | ------------------------------------- |
| `xdl_ld`  | Link object files into an XDL library |
| `readxdl` | Inspect XDL libraries                 |

## Build Summary

```bash
gcc -c one.c -o one.o
gcc -c two.c -o two.o

nasm -f elf64 helper.asm -o helper.o

xdl_ld -o world.xdl \
    one.o \
    two.o \
    helper.o
```

The final result is:

```text
world.xdl
```

Remember: **XDL is a library, not an executable. It must not contain `main`, `start`, or an executable entry point.**

