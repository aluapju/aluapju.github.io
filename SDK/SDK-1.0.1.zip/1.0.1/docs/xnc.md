# XNC Toolchain

XNC is the executable image format used by XNCOS userspace programs.

The XNseries SDK provides the following XNC development tools:

```text
SDK/tools/xnc/
├── xnc_xo
├── xnc_ld
├── readxo
└── readxnc
```

## Tools

### xnc_xo

`xnc_xo` combines object files into an XO object.

### xnc_ld

`xnc_ld` links XO/object input and produces an XNC executable image.

### readxo

`readxo` reads and displays information from an XO object.

### readxnc

`readxnc` reads and displays information from an XNC executable image.

---

# XNC Build Methods

The XNC toolchain provides multiple development approaches.

Currently documented methods:

1. **Method 1 — Standalone XNC**
2. **Method 2 — XNDS Dynamic Dependencies**

A third development approach is not currently documented because its complete compilation procedure is not available.

---

# Method 1 — Standalone XNC

Method 1 does not require external XNDS dependencies.

The basic build flow is:

```text
C source
   │
   │ gcc
   ▼
Object files
   │
   ├── xx.o
   ├── main.o
   └── start.o
          │
          │ xnc_ld
          ▼
       XNC image
```

## Requirements

No external runtime dependency is required.

The developer needs:

* GCC or another compiler capable of producing compatible object files
* `xnc_ld`
* object files
* `linker.ld`

## 1. Compile C source

Compile each C source file into an object file:

```bash
gcc -c foo.c -o foo.o
gcc -c main.c -o main.o
gcc -c start.c -o start.o
```

Additional source files can be compiled in the same way.

## 2. Link object files

Pass the object files directly to `xnc_ld`:

```bash
xnc_ld -o XXX.xnc \
    foo.o \
    main.o \
    start.o \
    -T linker.ld
```

This produces the XNC executable:

```text
XXX.xnc
```

---

# Method 2 — XNDS Dynamic Dependencies

Method 2 is used when the XNC program requires external dynamic dependencies through **XNDS**.

XNDS allows the executable to use functionality provided by external XDL libraries rather than placing every dependency directly into the executable.

The basic build flow is:

```text
C source
   │
   │ gcc
   ▼
.o
   │
   │ xnc_xo
   ▼
.xo
   │
   │ xnc_ld
   ▼
.xnc
   │
   └── external XNDS dependencies
```

## Requirements

The developer needs:

### Tools

```text
xnc_ld
xnc_xo
```

### Possible additional file

```text
linker.ld
```

The linker script depends on the program being built.

## 1. Compile C source files

Compile the C source files into object files:

```bash
gcc -c one.c -o one.o
gcc -c two.c -o two.o
gcc -c main.c -o main.o
gcc -c start.c -o start.o
```

The resulting files are:

```text
one.o
two.o
main.o
start.o
```

## 2. Create an XO

Use `xnc_xo` to combine the object files:

```bash
xnc_xo -o world.xo \
    one.o \
    two.o \
    main.o \
    start.o
```

This produces:

```text
world.xo
```

## 3. Link the XO into XNC

Pass the XO to `xnc_ld`:

```bash
xnc_ld -o world.xnc world.xo
```

The resulting executable is:

```text
world.xnc
```

The XNC executable can then reference the required external dynamic dependencies through XNDS.

---

# Important: start.asm

**You must provide a `start.asm` for your XNC program.**

The XNC loader needs an appropriate entry point before it can enter the program.

A typical build therefore contains:

```text
start.asm
main.c
other.c
```

which become:

```text
start.o
main.o
other.o
```

and are then passed through the XNC build process.

For example:

```bash
gcc -c main.c -o main.o
gcc -c other.c -o other.o
nasm -f elf64 start.asm -o start.o
```

The exact `start.asm` implementation depends on the program's runtime requirements.

Without an appropriate startup object and entry point, the loader cannot correctly enter the program.

---

# Linker Script Recommendation

**Using an explicit `linker.ld` is strongly recommended.**

When using `xnc_ld`, do not rely on the compiler's default linker script.

Compiler default linker scripts may contain settings that are not appropriate for the XNC userspace execution environment.

Therefore, when a linker script is required, explicitly specify it:

```bash
xnc_ld -o XXX.xnc \
    input.o \
    -T linker.ld
```

or, for an XO:

```bash
xnc_ld -o world.xnc \
    world.xo \
    -T linker.ld
```

## Linker Script Documentation

Detailed information about the XNC linker script is available at:

[XNseries SDK — Linker Script Documentation](https://aluapju.github.io/SDK/linker-script?utm_source=chatgpt.com)

> The online linker-script documentation is part of the XNseries SDK documentation site.

---

# Inspecting XO Files

After producing an XO file, use `readxo` to inspect it:

```bash
readxo world.xo
```

This is useful for verifying the XO header and contained objects.

---

# Inspecting XNC Files

After producing an XNC executable, use `readxnc`:

```bash
readxnc world.xnc
```

This can be used to inspect the generated XNC header and executable metadata.

---

# Method Comparison

| Feature                  | Method 1     | Method 2        |
| ------------------------ | ------------ | --------------- |
| External XNDS dependency | No           | Yes             |
| `xnc_ld`                 | Required     | Required        |
| `xnc_xo`                 | Not required | Required        |
| `.o` → `.xnc`            | Direct       | Via `.xo`       |
| `.xo`                    | Optional     | Required        |
| `linker.ld`              | Recommended  | May be required |
| `start.asm`              | Required     | Required        |

---

# Recommended Development Workflows

## Method 1

```text
.c
 │
 ▼
gcc
 │
 ▼
.o
 │
 ▼
xnc_ld
 │
 ├── linker.ld
 │
 ▼
.xnc
```

Example:

```bash
gcc -c main.c -o main.o
gcc -c other.c -o other.o
nasm -f elf64 start.asm -o start.o

xnc_ld -o world.xnc \
    main.o \
    other.o \
    start.o \
    -T linker.ld
```

## Method 2

```text
.c
 │
 ▼
gcc
 │
 ▼
.o
 │
 ▼
xnc_xo
 │
 ▼
.xo
 │
 ▼
xnc_ld
 │
 ▼
.xnc
 │
 └── XNDS dependencies
```

Example:

```bash
gcc -c one.c -o one.o
gcc -c two.c -o two.o
gcc -c main.c -o main.o
nasm -f elf64 start.asm -o start.o

xnc_xo -o world.xo \
    one.o \
    two.o \
    main.o \
    start.o

xnc_ld -o world.xnc world.xo
```

---

# Method 3

A third XNC development approach exists, but its complete compilation procedure is not currently available.

It is therefore **not included as a supported build procedure in this SDK version**.

The documentation will be updated when a complete and reproducible build process is available.

---

# Tool Summary

| Tool      | Purpose                      |
| --------- | ---------------------------- |
| `xnc_xo`  | Combine object files into XO |
| `readxo`  | Inspect XO files             |
| `xnc_ld`  | Link input into XNC          |
| `readxnc` | Inspect XNC files            |

## Important Notes

1. An appropriate `start.asm` is required so that the XNC loader can enter the program.
2. An explicit `linker.ld` is strongly recommended.
3. Do not assume that the compiler's default linker script is suitable for XNC.
4. Method 2 is intended for programs using external XNDS dynamic dependencies.
5. Method 3 is not currently documented as a supported build method.

