# SDK Layout

```text
SDK/
├── include/
├── library/
├── tools/
│   ├── xdl/
│   ├── xnc/
│   └── xkd/
└── docs/
```

`include/` contains public headers.

`library/` contains the BCL library artifacts required by the userspace
link/build process.

`tools/` contains the public XNseries development tools.

`docs/` contains SDK and toolchain documentation.
