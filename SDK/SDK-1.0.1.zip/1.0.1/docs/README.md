# XNseries SDK v1.0.0

The XNseries SDK provides the public userspace headers, libraries, and
development tools used to build XNseries applications.

## Components

- `include/` — public userspace API headers.
- `library/` — BCL library artifacts used during linking.
- `tools/xdl/` — XDL development tools.
- `tools/xnc/` — XNC development tools.
- `tools/xkd/` — XKD development tools.
- `docs/` — SDK documentation.

## API model

Userspace applications call public BCL APIs. BCL is responsible for the
system-call boundary; applications do not directly wire these APIs to
kernel syscalls.

## Build pipeline

```text
source
  -> compiler
  -> SDK/include
  -> object files
  -> SDK/library
  -> XNC/XDL tools
  -> userspace image
```
