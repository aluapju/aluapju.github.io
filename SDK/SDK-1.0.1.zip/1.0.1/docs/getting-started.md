# Getting Started

1. Install the XNseries SDK.
2. Add `SDK/include` to the userspace compiler include path.
3. Make the BCL library artifact available through `SDK/library`.
4. Build the userspace source into an object file.
5. Link against the BCL library.
6. Use the XNC/XDL development tools to produce the target image.
7. Install the resulting image into the XNCOS root filesystem.

The exact compiler and linker command is defined by the XNseries toolchain.
