# Building with the SDK

A complete build command depends on the BCL-1.0.0 library artifact and the
XNseries compiler/linker toolchain.

The SDK therefore does not prescribe a library filename or linker command
until those artifacts are fixed by the BCL/toolchain build configuration.

The public include path is:

```text
SDK/include
```

The public development tools are:

```text
SDK/tools/xdl
SDK/tools/xnc
SDK/tools/xkd
```
