# SDK Library

This directory is reserved for the BCL library artifacts used when building
XNseries userspace programs.

The exact library format and build command are intentionally not fabricated
here. They must match the BCL-1.0.0 build system and XDL/XNC toolchain.

Expected public BCL symbols are documented in `../docs/bcl-api.md`.
